﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

            }
            catch (Exception ex)
            {

                throw;
            }
            catch(System.IO.FileNotFoundException ex)
            {

            }
            List<student> _student = new List<student>();
            _student.Add(new student { Name = "D", age = 20 });
            _student.Add(new student { Name = "A", age = 55 });
            _student.Add(new student { Name = "r", age = 28 });
            _student.Add(new student { Name = "V", age = 10 });
            _student.Add(new student { Name = "S", age = 5 });
            _student.Add(new student { Name = "C", age = 20 });
            _student.Add(new student { Name = "W", age = 30 });
            //List<student> _newSt = (from _s in _student
            //             orderby _s.Name
            //             where _s.age > 15
            //             select new student { Name = _s.Name, age = _s.age }).ToList() ;

            List<student> _nwSt = _student.Where(s => s.age > 15).OrderBy(s => s.Name).Select(s => new student { Name = s.Name, age = s.age }).ToList();

            string a = "758294"; //245789
            char[] _a = a.ToArray();
            Array.Sort(_a);

            char[] _c = _a.Clone();

            _a.CopyTo(_c,0);

            string _b = new string(_a);
            Console.WriteLine(_b.ToString());
            Console.Read();
        }
    }

    class student
    {
        public string Name { get; set; }
        public int age { get; set; }
    }
}
